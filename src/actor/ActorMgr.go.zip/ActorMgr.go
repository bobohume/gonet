package actor
//作废
import (
	"sync/atomic"
	"base"
)

const (
	ADD_ACTOR =iota
	DEL_ACTOR =iota
)

type (
	ActorMgr struct{
		m_ActorMap		map[int] IActor
		m_CallChan   	chan ActorChan
		m_nIdSeed       int32
		m_Chan			chan CallIO
	}

	IActorMgr interface {
		AssignClientId() int
		Init() int
		AddActor(IActor)
		DelActor(IActor)
		NotifyActor(IActor, int)
		SendMsg(int, string, ...interface{})
	}

	ActorChan struct {
		pActor IActor
		state int
	}

	MsgChan struct{
		Id int
		Msg []byte
	}
)

var(
	pActorMgr *ActorMgr
)

func (this *ActorMgr) Init() {
	this.m_ActorMap = make(map[int] IActor)
	this.m_CallChan = make(chan ActorChan, 1000)
	this.m_nIdSeed = 0
	this.m_Chan = make(chan CallIO, 1000)
	go actorMgrRoutine(this);
}

func (this *ActorMgr) AddActor(pActor IActor) {
	//pActor.m_pActorMgr = this
	this.NotifyActor(pActor,ADD_ACTOR)
}

func (this *ActorMgr) DelActor(pActor IActor){
	this.NotifyActor(pActor,DEL_ACTOR)
}

func (this *ActorMgr) NotifyActor(pActor IActor, state int){
	var actorChan ActorChan
	actorChan.pActor = pActor
	actorChan.state = state
	this.m_CallChan <- actorChan
}

func (this *ActorMgr) AssignClientId() int {
	atomic.AddInt32(&this.m_nIdSeed, 1)
	return int(this.m_nIdSeed)
}

//call rpc when konw actor id
func (this *ActorMgr) SendMsg(caller Caller, funcName string, params  ...interface{}){
	var io CallIO
	io.ActorId = caller.ActorId
	io.SocketId = caller.SocketId
	io.Buff = base.GetPacket(funcName, params)
	this.m_Chan <- io
}

func actorMgrRoutine(pActorMgr *ActorMgr) {
	if pActorMgr == nil{
		return 
	}
	for {
		select {
		case io:= <-pActorMgr.m_Chan :
			pActor, exist := pActorMgr.m_ActorMap[io.ActorId]
			if exist == true && pActor != nil{
				pActor.Send(io)
			}
		case actorState:= <-pActorMgr.m_CallChan:
			if actorState.state == ADD_ACTOR{
				pActorMgr.m_ActorMap[actorState.pActor.GetId()] = actorState.pActor
			}else if(actorState.state == DEL_ACTOR){
				delete(pActorMgr.m_ActorMap, actorState.pActor.GetId())
			}
		}
	}
}
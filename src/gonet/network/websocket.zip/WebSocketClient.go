package network

import (
	"fmt"
	"github.com/gorilla/websocket"
	"gonet/base"
	"io"
)

type IWebSocketClient interface {
	ISocket
}

type WebSocketClient struct {
	Socket
	m_pServer     *WebSocket
	m_WebConn 	  *websocket.Conn
}

func (this *WebSocketClient) Start() bool {
	if this.m_nState != SSF_SHUT_DOWN{
		return false
	}

	if this.m_pServer == nil {
		return false
	}

	if this.m_PacketFuncList.Len() == 0 {
		this.m_PacketFuncList = this.m_pServer.m_PacketFuncList
	}
	this.m_nState = SSF_ACCEPT
	go wserverclientRoutine(this)
	return true
}

func (this *WebSocketClient) Send(buff []byte) int {
	defer func() {
		if err := recover(); err != nil{
			base.TraceCode(err)
		}
	}()

	if this.m_WebConn == nil{
		return 0
	}

	err := this.m_WebConn.WriteMessage(websocket.BinaryMessage, buff)
	n := len(buff)
	handleError(err)
	if n > 0 {
		return n
	}
	return 0
}

func (this *WebSocketClient) OnNetFail(error int) {
	this.Stop()
	if this.m_nConnectType == SERVER_CONNECT{
		this.CallMsg("DISCONNECT", this.m_ClientId)
	}else{//netgate对外格式统一
		stream := base.NewBitStream(make([]byte, 32), 32)
		stream.WriteInt(int(DISCONNECTINT), 32)
		stream.WriteInt(this.m_ClientId, 32)
		this.HandlePacket(this.m_ClientId, stream.GetBuffer())
	}
}

func (this *WebSocketClient) Close() {
	if this.m_WebConn != nil{
		this.m_WebConn.Close()
	}
	this.m_WebConn = nil
	this.Socket.Close()
	if this.m_pServer != nil {
		this.m_pServer.DelClinet(this)
	}
}

func wserverclientRoutine(pClient *WebSocketClient) bool {
	if pClient.m_WebConn == nil {
		return false
	}

	defer func() {
		if err := recover(); err != nil {
			base.TraceCode(err)
		}
	}()

	for {
		if pClient.m_bShuttingDown {
			break
		}

		_, buff, err := pClient.m_WebConn.ReadMessage()
		n := len(buff)
		if err == io.EOF {
			fmt.Printf("远程链接：%s已经关闭！\n", pClient.m_WebConn.RemoteAddr().String())
			pClient.OnNetFail(0)
			break
		}
		if err != nil {
			handleError(err)
			pClient.OnNetFail(0)
			break
		}
		if n > 0 {
			pClient.ReceivePacket(pClient.m_ClientId, buff[:n])
		}
	}

	pClient.Close()
	fmt.Printf("%s关闭连接", pClient.m_sIP)
	return true
}